<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Deliveryrequest;
use App\Http\Controllers\RiderController;

class Requests extends Controller
{
    public function requestdelivery(Request $requests){
        $requestrider = new Ridercontroller;

        $input = $requests->all();

        if(empty($input['pick_up_location']) or empty($input['drop_up_location'])){
            return response()->json([
                "message" => 'pickup and dropoff location are compulsory'
            ]);
        }

        $pickuplocation = $input['pick_up_location'];
        $dropuplocation = $input['drop_up_location'];
        $vehicle_type = $input['vehicle_type'];
        $result = $requestrider->locationfinder($pickuplocation, $dropuplocation , $vehicle_type);

        return response()->json(
            $result->original
        );
    }

    
}
