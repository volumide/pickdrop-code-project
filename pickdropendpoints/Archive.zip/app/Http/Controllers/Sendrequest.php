<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Deliveryrequest;
use Illuminate\Support\Facades\Auth;

class Sendrequest extends Controller
{
    public function makerequest(Request $requests){
        $input = $requests->all();
        $input['uuid'] = (string) Str::uuid();
        $input['status'] = 'pending';

        $makerequest = Deliveryrequest::create($input);

        return response()->json([
            "data" => $makerequest
        ]);
    }

    public function riderlog(Request $request){
        $currentUser = Auth::user();
        if ($currentUser['status'] === "rider") {
            $status = Deliveryrequest::where('status', 'pending')->where('rider_uuid', $currentUser['uuid'])->get();

            return response()->json([
                "data"=> $status
            ]);
        }
    }

    public function updateridestatus($id){
        $status;
        $views = Deliveryrequest::find($id);
        $input = $views['status'];
        // dd($views->status);
        switch ($views->status) {
            case 'pending':
                $views->status = 'accepted';
                $status = 'Accepted';
                $views->save();
                break;
            case 'accepted':
                $views->status = 'picked up';
                $status = 'Picked up';
                $views->save();
                break;
            case 'picked up':
                $views->status = 'completed';
                $status = 'completed';
                $views->save();
                break;
            default:
                $status = 'No obvious change noticed';
                break;
        }
        return response()->json([
            "data"=> [
                "status"=> $views->status,
                "message"=> $status
            ]
        ]);
    }
}
