<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use App\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use JD\Cloudder\Facades\Cloudder;


class Authcontroller extends Controller
{

    public function signup(Request $request){
        $checkvalidation = Validator::make($request->all(), [
            'name' => 'required|min:3',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6',
            'phone' => 'required|unique:users'
        ]);

        if($checkvalidation->fails()){
            return response()->json([
                "message"=> "user already exists"
            ]);
        }

        $input = $request->all();

        $input['email']= filter_var($input['email'], FILTER_SANITIZE_EMAIL);

        if (!filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
            return response()->json([
                "message"=> "invalid email address"
            ]);
        }

        $input['uuid'] = (string) Str::uuid();
        $input['password'] = bcrypt($input['password']);

        // $status = $request->input('status');
        if (empty($input['status'])) {
            $input['status'] = 'customer';
        }else{
            $input['status'] = 'rider';
        }

        $user = User::create($input);
        $token = $user->createToken('app')->accessToken;

        return response()->json([
            "status" => "success",
            "data" => $user,
            "token"=>$token,
            "message" => "Registration successfull."
                
            ], 200
        );
    }

    public function signin(Request $request){
        $userdetails = [
            "email" => $request->email,
            "password"=> $request->password
        ];

        // $authenticate = Auth::attempt($userdetails);
        if( Auth::attempt($userdetails)){
            $user = $request->user();
            $token = $user->createToken('Personaltoken')->accessToken;
            return response()->json([
                "data" => [ 
                    'content'=> $user,
                    "token" => $token
                    ]
                ], 200
            );
        }else{
            return response()->json([
                "error" => [ 
                    "message" => "unathorised"
                    ]
                ], 401
            );
        }
    }

    public function viewall(){
        $views = User::all();
        return \response()->json([
            "data"=> [
                "allusers" => $views
                ]
            ], 201
        );
    }

    public function viewuser(Request $request, $id){
        $views = User::findOrfail($id);
        return \response()->json([
            "data"=> [
                "allusers" => $views
                ]
            ], 201
        );
    }

    public function updateprofile(Request $request){
        $data = $request->all();
        $user = Auth::user();

        User::where('uuid', $user['uuid'])->update($data);
        return response()->json([
            "data"=> [
                "profile"=>  User::where('uuid', $user['uuid'])->first(),
                "message"=> "Profile updated successfully"
            ]
        ]);
    }  

    public function uploadpic(Request $request){
        $data = $request->all();

        $user = Auth::user();

        if(Cloudder::upload($data['picture'], null)) {
            $upload_result = Cloudder::getResult();
            $data = array(
              'picture' => $upload_result['url']
            );

           if(User::where('uuid', $user['uuid'])->update($data)) {
                return response()->json([
                'status' => 'success',
                'message' => 'User picture updated successfully',
                'data' => User::where('uuid', $user['uuid'])->first()
             ], 200);   
            } else {
                return response()->json([
                'status' => 'failed',
                'message' => 'Error occurred while updating profile picture.'
             ], 401);
            }
        };

    }
}
