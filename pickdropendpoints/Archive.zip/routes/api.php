<?php

use Illuminate\Http\Requests;
use App\Http\Controllers\Authcontroller;
use App\Http\Controllers\Ridercontroller;
use App\Http\Controllers\Sendrequest;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Auth::routes(['verify' => true]);

Route::group(['prefix'=> 'v1'], function (){
	Route::post('signup', 'Authcontroller@signup');
	Route::post('signin', 'Authcontroller@signin');
	
	Route::middleware('auth:api')->group(function () {
		Route::put('upload', 'Authcontroller@uploadpic');
		Route::get('allusers', 'Authcontroller@viewall');
		Route::get('userprofile/{id}', 'Authcontroller@viewuser');
		Route::put('userupdate', 'Authcontroller@updateprofile');
		Route::post('findrider', 'Requests@requestdelivery');
		Route::post('makerequest', 'Sendrequest@makerequest');
		Route::get('riderlogs', 'Sendrequest@riderlog');
		Route::put('updatedeliverystatus/{id}', 'Sendrequest@updateridestatus');
		Route::put('update/location', 'Authcontroller@updateprofile');
	});

});

// Route::get('location/{location}', 'Ridercontroller@calccoordinate');
